# LamaStudio School Suite

Free, multi-school institutional management platform for lamastudio.pk.
Every school registers itself, gets its own live Google Sheet database, and
runs three panels: **Super Admin** (you), **School Admin**, and a combined
**Teacher / Student Portal**.

See [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) for how the pieces fit
together and how to extend it.

## The three panels

**Super Admin** (`superadmin-login.html` → `superadmin-dashboard.html`)
Total schools, active schools, total students, total teachers across the
whole platform. Block/unblock a school, reset its password.

**School Admin** (`login.html` → `dashboard.html`)
Today's absentees, attendance ratio, today's fee collection, a 12-month
income graph, recent notices. From here: admissions, result cards, report
cards, date sheet, tests, notifications, manage teachers, fee collection.

**Teacher / Student Portal** (`portal-login.html`)
- Teachers → `teacher-dashboard.html`: mark attendance, assign homework,
  enter marks, send notices to their class.
- Students → `student-portal.html`: view their own result, homework,
  attendance history, and notices.

## Repo layout

```
lamastudio-school-suite/
├── README.md
├── .gitignore
├── docs/
│   └── ARCHITECTURE.md
├── backend/
│   └── code.gs                   Apps Script Web App (deploy separately)
└── public/                       Upload this folder's contents to your web host
    ├── register.html             Public self-signup (School Admin)
    ├── login.html                School Admin login
    ├── portal-login.html         Teacher + Student login
    ├── superadmin-login.html     Your login
    ├── superadmin-dashboard.html Platform-wide stats & school management
    ├── dashboard.html            School Admin overview
    ├── admissions.html
    ├── result-card.html
    ├── report-card.html
    ├── date-sheet.html
    ├── tests.html
    ├── notifications.html
    ├── settings.html             School edits its own profile
    ├── manage-teachers.html      School Admin creates teacher accounts
    ├── fees.html                 School Admin fee collection
    ├── teacher-dashboard.html
    ├── student-portal.html
    ├── api-client.js             LamaAPI — every page calls this, never Sheets directly
    └── config.css
```

`public/` must stay flat — every page references `api-client.js` and
`config.css` with no folder prefix.

## Setup

1. [script.google.com](https://script.google.com) → New project → paste in
   `backend/code.gs`.
2. Run `setup` once (creates your Master Registry spreadsheet).
3. Near the top of the file, change `SUPER_ADMIN_PASSWORD_PLAINTEXT` to your
   own password, then run `setupSuperAdmin` once.
4. Deploy → New deployment → Web app → Execute as **Me** → Who has access
   **Anyone** → Deploy. Copy the `/exec` URL.
5. Paste that URL into `public/api-client.js` as `API_URL`.
6. Upload everything in `public/` to lamastudio.pk.

To edit the backend later: Deploy → Manage deployments → pencil icon →
New version → Deploy. This keeps the same URL.

## How a teacher or student gets an account

Teachers and students don't self-register. The School Admin creates a
teacher account from `manage-teachers.html` (name, email, password, assigned
class) and shares the school's **School ID / Login Code** (shown on that
same page) — the teacher then logs in at `portal-login.html`. Students log
in the same way with their enrollment number; their password defaults to
their enrollment number and can be changed by re-saving them from
`result-card.html`.

## Known limitations

- No email delivery guarantee for password resets — the new password is
  also shown directly to you in the Super Admin dashboard as a fallback.
- Session tokens don't expire on their own — fine for a free small-scale
  tool, not bank-grade security.
- A teacher currently manages one assigned class; multi-class teachers need
  one account per class for now.

See `docs/ARCHITECTURE.md` for the full data schema and permission model.
