# Architecture blueprint (v2 — multi-role)

## Overview
One Apps Script Web App (`backend/code.gs`) serves every school and every
role. Each school still owns one private Google Sheet, now with more tabs;
one shared "Master Registry" spreadsheet maps schools to their sheet, login
credentials, and active/blocked status, and also holds your Super Admin
password hash.

## Roles

| Role | Logs in at | Session identity | Scope |
|---|---|---|---|
| School Admin | `login.html` | `schoolId` + `apiKey` | Full CRUD on their own school's sheet |
| Teacher | `portal-login.html` | `schoolId` + `teacherId` + `apiKey` | Attendance/homework/notices: their own class only. Students: read + marks update, own class only. Read-only on date sheet/tests |
| Student | `portal-login.html` | `schoolId` + `studentId` + `apiKey` | Read-only: their own student record, their own class's homework/date sheet/tests/notifications |
| Super Admin | `superadmin-login.html` | a single password hash (no `schoolId`) | Registry-level only: list schools, block/unblock, reset a school's password. No access to any school's actual data |

`api-client.js` stores whichever session is active in `localStorage` under
one key, tagged with a `role` field, and sends the right identity fields
with every request automatically. `requireLogin(role, loginPage)` at the top
of every page redirects anyone logged in as the wrong role (or not logged in
at all) to the right login page.

## Per-school spreadsheet tabs

- **Students** — `id, enrlNo, name, gender, dob, fatherGuardian, contact,
  class, subjectsJson, position, photo, behavioralJson, attendance,
  teacherRemarks, principalRemarks, remarks, password, apiKey, createdAt`.
  `attendance` here is a legacy manually-typed percentage field from the
  report card — separate from the new per-day **Attendance** tab below.
- **Teachers** — `id, name, email, passwordHash, apiKey, subject,
  assignedClass, contact, status, createdAt`. Created only by a School
  Admin via `manage-teachers.html` — teachers never self-register.
- **Attendance** — `id, studentId, studentName, class, date, status,
  markedBy, createdAt`. One row per student per day.
- **Homework** — `id, class, subject, title, description, dueDate,
  assignedBy, createdAt`.
- **Fees** — `id, studentId, studentName, class, amount, date, status,
  method, createdAt`.
- **DateSheet**, **Tests**, **Notifications** — unchanged from v1.

Fields ending in `Json` (e.g. `subjectsJson`) are stored as JSON text in one
cell and appear to the frontend as the plain field name (`subjects`) — the
generic `rowToRecord`/`recordToRow` helpers in `code.gs` handle this
transparently.

## Permission enforcement

All of it lives server-side in `checkPermission()` and the filtering inside
`listRecords()`/`getRecord()` in `code.gs` — the frontend never decides what
it's allowed to see. Concretely:

- A teacher's `list('students')` / `list('attendance')` / `list('homework')`
  is filtered to rows where `class === teacher.assignedClass` before it
  ever reaches the response.
- A student's `get('students', id)` is rejected unless `id` is their own.
  Their `list('homework' | 'datesheet' | 'tests')` is filtered to their own
  `class`. `notifications` is not class-filtered — it's treated as a
  school-wide broadcast, same as v1.
- Anything not explicitly allowed in `checkPermission()` throws, and the
  frontend surfaces that as an error rather than silently showing nothing.

## Dashboard stats

`getDashboardStats()` (School Admin only) opens the school's own sheet once
per call and computes: total students, present/absent today, attendance
ratio, today's "Paid" fee total, a 12-month trailing income series grouped
by `YYYY-MM`, and the 5 most recent notifications. `dashboard.html` renders
this directly — there's no separate caching layer, so very large schools
may notice this call take longer; fine at the scale this is built for.

## Super Admin

`adminListSchools()` iterates the Master Registry and, for each school,
opens their sheet just long enough to count non-empty rows in Students and
Teachers — this is the one place the platform reads across every school at
once, and it's read-only (counts only, never the actual student/teacher
data). `adminSetStatus()` flips a school's `status` cell directly.
`adminResetPassword()` generates a new password, updates the hash, attempts
to email it via `MailApp`, and always returns the plaintext to the Super
Admin dashboard too, since email delivery isn't guaranteed.

## Known limitations (v2)

- Teacher accounts are one-class-only for now — a teacher who teaches
  multiple classes needs a separate account per class.
- Session tokens don't expire on their own (tied to the password hash, not
  time-limited).
- `adminListSchools()` opens every school's spreadsheet on every call —
  fine for tens of schools, worth adding caching if the platform grows into
  the hundreds.
- No automated recurring fee generation (e.g. "charge everyone Rs. 2000 on
  the 1st") — fee entries are added one at a time from `fees.html`.

## Extending it

- New field on a student: add a column to the `Students` tab + the header
  list in `COLLECTIONS.students.headers` in `code.gs`, then read/write it
  from whichever page needs it — no other backend change required.
- New collection: add a tab + entry to `COLLECTIONS`, decide which roles can
  touch it in `checkPermission()`, then call `LamaAPI.list('yourCollection')`
  etc. from a new page.
- New role: give it its own login function (mirroring `teacherLogin`/
  `studentLogin`), its own `authorizeX()` function, a branch in
  `resolveContext()`, and permission rules in `checkPermission()`.
